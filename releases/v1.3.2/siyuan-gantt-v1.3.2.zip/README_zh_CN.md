# siyuan-gantt v1.3.2

发布包 v1.3.2：包含小尺寸 icon/preview、性能剖析工具，并改进了 events/resources 的更新逻辑以提升大数据集时的性能。