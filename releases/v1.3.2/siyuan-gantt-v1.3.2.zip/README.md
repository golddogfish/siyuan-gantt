# siyuan-gantt v1.3.2

Release bundle for v1.3.2 — includes smaller icon/preview, profiling tools, and performance improvements to events/resources updating.
